button = document.getElementById('button')
button.onclick = function(){
	
}